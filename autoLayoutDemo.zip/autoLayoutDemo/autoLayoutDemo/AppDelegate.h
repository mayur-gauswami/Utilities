//
//  AppDelegate.h
//  autoLayoutDemo
//
//  Created by Mayur Gosai on 05/01/14.
//  Copyright (c) 2014 Mayur Gosai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
